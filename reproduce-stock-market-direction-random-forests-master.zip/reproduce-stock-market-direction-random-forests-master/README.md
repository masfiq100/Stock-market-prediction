# reproduce-stock-market-direction-random-forests
Reproduce research from paper "Predicting the direction of stock market prices using random forest"

Khaidem, Luckyson, Snehanshu Saha, and Sudeepa Roy Dey. "Predicting the direction of stock market prices using random forest." arXiv preprint arXiv:1605.00003 (2016). [paper](https://arxiv.org/abs/1605.00003)

This is my attemp to reproduce this paper. In my way I found that the results I got are much worse than those from the authors and I wonder if the authors accidentaly had a data leakage issue. 

Please, let me know if you notice any mistake in the analysis / code or if you feel there is something I misunderstood.
